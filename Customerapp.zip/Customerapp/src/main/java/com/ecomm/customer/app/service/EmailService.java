package com.ecomm.customer.app.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ecomm.customer.app.modal.CustomerInfo;
import com.ecomm.customer.app.modal.EmailTemplate;



@Service 
public class EmailService {
	@Value("${application.send.email.url}")

	
	private String sendEmailEndPoint;

	public String sendEmail(CustomerInfo customerInfo) {
		RestTemplate restTemplate = new RestTemplate();
		EmailTemplate emailTemplate = new EmailTemplate();
		String emailBody="Hell "+customerInfo.getCustomerName()+",\n"
				+"\n"
		+"Welcome to our app"
		+"\n"
		+"Enjoy shopping.."
		+"\n"
		+"Thanks and Regards,\n"
		+"E-Comm Support Team";
		String subject = "Welcome..";
		emailTemplate.setToAddress(customerInfo.getCustomerEmail());
		emailTemplate.setSubject(subject);
		emailTemplate.setEmailBody(emailBody);
		emailTemplate.setAttachmentRequired(false);
		
		ResponseEntity<String> response=restTemplate.postForEntity(sendEmailEndPoint, emailTemplate, null);
		return response.getBody();
}
}
